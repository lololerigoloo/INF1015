/*
    INF1015 - Programmation I
    TP1 - Exercices 1 à 5
    Auteur: Laurent Corbeil et Tristan Gagné
    Date: 2026-01-20
    Description: Programme principal qui exécute les exercices 1 à 5 pour le TP1 de inf1015 hiver 2026.
    attention de mettre le 
*/

#include <iostream>
#include <fstream>
#include <string>
#include <random>

using namespace std;
const string FICHIER_ETUDIANTS = "INF1015-TD1-H26-Fichiers/etudiants.txt"; // Chemin du fichier des étudiants a changer si besoin
const string FICHIER_ALIMENTS = "INF1015-TD1-H26-Fichiers/aliments.txt"; // Chemin du fichier des aliments a changer si besoin

// Début de exercice1.cpp
void exercice1()
{
    int n;

    cout << "Entrez la hauteur du triangle isocèle: ";
    cin >> n;

    for (int i = 1; i <= n; ++i)
    {
        // Afficher les espaces
        for (int j = i; j < n; ++j)
        {
            cout << " ";
        }
        // Afficher les étoiles
        for (int k = 1; k <= (2 * i - 1); ++k)
        {
            cout << "*";
        }
        cout << endl;
    }
}
// Fin de exercice1.cpp

// Début de exercice2.cpp
string caeserCipher(string phrase, int decalage)
{
    for (int i = 0; i < phrase.length(); i++)
    {
        if (isalpha(phrase[i]))
        {
            char caractere = islower(phrase[i]) ? phrase[i] : tolower(phrase[i]);
            phrase[i] = (caractere - 'a' + decalage) % 26 + 'a';
        }
        else
        {
            phrase[i] = '&'; // Ne pas modifier les caractères non alphabétiques
        }
    }
    return phrase;
}
bool isValidShift(int decalage)
{
    return decalage >= 1 && decalage <= 17; // regarder si le décalage est entre 1 et 17
}

int exercice2()
{
    while (true)
    {
        int decalage;
        string phrase;

        cout << "Entrez le décalage (entre 1 et 17): ";
        cin >> decalage;
        cin.ignore(); // Ignorer le caractère de nouvelle ligne restant dans le flux d'entrée

        if (isValidShift(decalage))
        {
            cout << "Entrez la phrase à chiffrer: ";
            getline(cin, phrase);

            string phraseChiffree = caeserCipher(phrase, decalage);
            cout << "Phrase chiffrée: " << phraseChiffree << endl;
            break; // Sortir de la boucle après un chiffrement réussi
        }
        else
        {
// Debut Extra pris sur https://stackoverflow.com/questions/6486289/clear-console-screen-in-c
#ifdef _WIN32
            std::system("cls");
#else
            // Assume POSIX or other non-Windows
            std::system("clear");
#endif
            // Fin Extra pris sur https://stackoverflow.com/questions/6486289/clear-console-screen-in-c
            cout << "Décalage invalide. Veuillez entrer un nombre entre 1 et 17." << endl;
        }
    }
    return 0;
}

// Fin de exercice2.cpp

// Debut de exercice3.cpp
double max(double valeurs[], int nbrelem)
{
    for (int i = 1; i < nbrelem; i++)
    {
        if (valeurs[i] > valeurs[0])
        {
            valeurs[0] = valeurs[i];
        }
    }
    return valeurs[0];
}
double min(double valeurs[], int nbrelem)
{
    for (int i = 1; i < nbrelem; i++)
    {
        if (valeurs[i] < valeurs[0])
        {
            valeurs[0] = valeurs[i];
        }
    }
    return valeurs[0];
}
int nombreElements(ifstream &fichier)
{
    string ligne;
    int compteur = 0;
    while (getline(fichier, ligne))
    {
        compteur++;
    }
    cout << "Nombre d'éléments: " << compteur << endl;
    return compteur;
}
void transformerEnTableau(ifstream &fichier, double valeurs[])
{
    int compteur = 0;
    string nom;
    int valeur;
    while (fichier >> nom >> valeur)
    {
        valeurs[compteur] = valeur;
        compteur++;
    }
}

void exercice3()
{
    ifstream fichier(FICHIER_ALIMENTS);
    if (!fichier)
    {
        cout << "Erreur lors de l'ouverture du fichier." << endl;
        return;
    }
    else
    {
        cout << "Fichier ouvert avec succès." << endl;
        int nbrelem = nombreElements(fichier);
        fichier.clear();            // Réinitialiser les indicateurs d'état du flux
        fichier.seekg(0, ios::beg); // Revenir au début du fichier
        double valeurs[nbrelem];
        transformerEnTableau(fichier, valeurs);
        for (int i = 0; i < nbrelem; i++)
        {

            valeurs[i] = valeurs[i];
        }

        double maximum = max(valeurs, nbrelem);
        double minimum = min(valeurs, nbrelem);
        cout << "La valeur maximum est: " << maximum << endl;
        cout << "La valeur minimum est: " << minimum << endl;
    }
}
// Fin de exercice3.cpp

// Debut de exercice4.cpp
const int rangees = 20;
const int placesParRangee = 10;

void initialiserTableau(int tableau[rangees][placesParRangee])
{
    random_device rd;
    mt19937 gen(rd());
    uniform_int_distribution<> dis(0, 1);

    for (int i = 0; i < rangees; i++)
    {
        for (int j = 0; j < placesParRangee; j++)
        {
            tableau[i][j] = dis(gen);
        }
    }
}

void afficherTableau(int tableau[rangees][placesParRangee])
{
    for (int i = 0; i < rangees; i++)
    {
        for (int j = 0; j < placesParRangee; j++)
        {
            cout << tableau[i][j];
        }
        cout << endl;
    }
}
bool estDemandeValide(int n)
{
    return n >= 1 && n <= placesParRangee;
}
void afficherPossibiliter(int tableau[rangees][placesParRangee], int nbplace)
{

    /* important les sieges sont numérotés comme suit : 1 2 3 4 5 6 7 8 9 10 rangée 1
                                                        1 2 3 4 5 6 7 8 9 10 rangée 2
                                                        ...
                                                        ...
                                                        */
    int compteur = 0;
    for (int i = 0; i < rangees; i++)
    {
        for (int j = 0; j < placesParRangee; j++)
        {
            if (tableau[i][j] == 0)
            {

                compteur++;
                if (compteur == nbplace)
                {
                    cout << "rangee " << i + 1 << " sieges " << j - nbplace + 2 << " à " << j + 1 << endl;
                    compteur--;
                }
            }
            else
            {
                compteur = 0;
            }
        }
        compteur = 0;
    }
}
void exercice4()
{
    int cinema[rangees][placesParRangee];
    initialiserTableau(cinema);
    while (true)
    {
        int n;
        cout << "Entrez le nombre de places libres à trouver (entre 1 et " << placesParRangee << "): ";
        cin >> n;

        if (estDemandeValide(int(n)))
        {
            afficherTableau(cinema);
            cout << "Recherche de " << n << " places libres..." << endl;
            afficherPossibiliter(cinema, n);
            break;
        }
        else
        {
            cout << "Demande invalide. Veuillez entrer un nombre entre 1 et " << placesParRangee << "." << endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
    }
}

// Fin de exercice4.cpp

// Debut de exercice5.cpp
struct Etudiant
{
    int matricule;
    string sigle;
};

void remplirEtudiant(Etudiant etudiant[], ifstream &fichier, int &nbrelem)
{
    while (fichier >> etudiant[nbrelem].matricule >> etudiant[nbrelem].sigle)
    {
        nbrelem++;
    }
    fichier.close();
}
void compterDomaine(Etudiant etudiant[], int nbrelem, int min, int max, const string domaine[], int compteur[])
{
    for (int i = 0; i < nbrelem; i++)
    {
        if (etudiant[i].matricule >= min && etudiant[i].matricule <= max)
        {
            for (int j = 0; j < 5; j++)
            {
                if (etudiant[i].sigle[0] == domaine[j][0])
                {
                    compteur[j]++;
                    break;
                }
                else if (j == 4)
                {
                    compteur[4]++;
                }
            }
        }
    }
}
void afficherResultat(int compteurDomaine[], const string domaine[])
{
    for (int j = 0; j < 5; j++)
    {
        if (j == 3)
        {
            cout << "Biomedicale      " << compteurDomaine[j] << endl;
            continue;
        }
        cout << domaine[j] << "      " << compteurDomaine[j] << endl;
    }
}

void exercice5()
{
    const string domaine[] = {"Electrique", "Informatique", "Logiciel", "GBM", "Autre"};
    ifstream fichier(FICHIER_ETUDIANTS);
    if (fichier.fail())
    {
        cout << "Erreur lors de l'ouverture du fichier." << endl;
        return;
    }
    Etudiant etudiants[400];
    int nbrelem = 0;
    remplirEtudiant(etudiants, fichier, nbrelem);
    while (true)
    {
        int min = 0;
        int max = 0;
        cout << "Entrer la plage de matricules (0 0 pour terminer): ";
        cin >> min >> max;
        if (min == 0 && max == 0)
        {
            break;
        }
        if (min > max)
        {
            cout << "Plage invalide. Le minimum doit être inférieur ou égal au maximum." << endl;
            continue;
        }
        cout << "Dans cette plage, il y a ces nombres d'etudiants dans chaque domaine: " << endl;
        int compteurDomaine[5] = {0};
        compterDomaine(etudiants, nbrelem, min, max, domaine, compteurDomaine);
        afficherResultat(compteurDomaine, domaine);
    }
}
// Fin de exercice5.cpp

// Début de main.cpp
int main()
{
    cout << "Exercice 1:" << endl;
    exercice1();
    cout << "\nExercice 2:" << endl;
    exercice2();
    cout << "\nExercice 3:" << endl;
    exercice3();
    cout << "\nExercice 4:" << endl;
    exercice4();
    cout << "\nExercice 5:" << endl;
    exercice5();
    cout << "\nTous les exercices sont terminés." << endl;
    return 0;
}
// Fin de main.cpp