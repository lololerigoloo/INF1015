Bonjour,
voici la remise du TP1 de Laurent Corbeil et Tristan Gagné.

Nous avons déposé tous les fichiers .cpp dans le dossier TP1 et les exécutables dans un sous-dossier nommé Executable.

Chacun des cinq problèmes se trouve dans un fichier nommé exercice<numéro>.cpp.

Toutefois, si vous souhaitez tout compiler d’un seul coup, le fichier dans le directoire fichierRemis a le fichier qui etait a remettre regroupe tous les exercices.
