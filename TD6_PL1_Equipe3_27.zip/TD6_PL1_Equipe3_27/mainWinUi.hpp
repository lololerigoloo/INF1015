// ============================================================
// mainWinUi.hpp — Fenêtre principale de l'application
// Namespace : Vue
// ============================================================
#pragma once
#include <QMainWindow>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QDebug>
#include <memory>
#include "Echiquier.hpp"         
#include "EchiquierWidget.hpp"
#include "SideWidget.hpp"
#include "annonceWidget.hpp"
#include "selecteurDeNiveau.hpp"
#include "piecePixmapManager.hpp"
    
namespace Vue
{
    class MainWinUi : public QMainWindow
    {
        Q_OBJECT
    public:
        MainWinUi();

    public slots:
        void placerPiece(const Position &position)
        {
            if (!echiquier_->estPositionValide(position) || !sideWidget_->estActif() || sideWidget_->modeCourant() != Mode::Placer)
                return;
            qDebug() << "Placer pièce en" << position.x() << position.y();
            echiquier_->ajouterPiece(pieceSelectionnee_, couleurSelectionnee_, position);
            echiquierWidget_->update();
        }

        void actionEffacer(const Position &position)
        {
            if (!echiquier_->estPositionValide(position) || !sideWidget_->estActif() || sideWidget_->modeCourant() != Mode::Effacer)
                return;
            echiquier_->enleverPiece(position);
            qDebug() << "Action Effacer";
            echiquierWidget_->update();
        }

        void changerSelection(Vue::TypePiece piece, Modele::Couleur couleur)
        {
            pieceSelectionnee_ = piece;
            couleurSelectionnee_ = couleur;

            qDebug() << "Selection changée";
        }
        void resizeEvent(QResizeEvent *event) override
        {
            QMainWindow::resizeEvent(event);

            int tailleCase = std::min(echiquierWidget_->width(), echiquierWidget_->height()) / Modele::Echiquier::N_CASES;
            Vue::PiecePixmapManager::instance().setTailleCase(tailleCase);

            echiquierWidget_->update();
        }

    private:
        std::shared_ptr<Modele::Echiquier> echiquier_;
        std::unique_ptr<Vue::EchiquierWidget> echiquierWidget_;
        std::unique_ptr<Vue::SideWidget> sideWidget_;
        std::unique_ptr<Vue::AnnonceWidget> annonceWidget_;
        std::unique_ptr<Vue::SelecteurDeNiveau> selecteurNiveau_;
        Vue::TypePiece pieceSelectionnee_;
        QTextEdit *textBox_;
        QWidget *secondWidget_;
        Modele::Couleur couleurSelectionnee_;
    };
}