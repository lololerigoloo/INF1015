// ============================================================
// Echiquier.hpp — Plateau de jeu, gestion des pièces
// Namespace : Modele
// ============================================================
#pragma once
#include <memory>
#include <vector>
#include <stdexcept>
#include "Position.hpp"
#include "blocInfomation.hpp"
#include "pieces/pieces.hpp"
#include "SideWidget.hpp"

namespace Modele
{
    class DeplacementManager;
    class Echiquier
    {
    public:
        Echiquier();
        ~Echiquier();
        void ajouterPiece(std::shared_ptr<Piece> piece);
        void ajouterPiece(Vue::TypePiece type, Couleur couleur, Position position);
        void enleverPiece(const Position &position)
        {
            if (estPositionValide(position))
                cases_[position.x()][position.y()] = nullptr;
        }
        void placerNiveau(const QString &niveau);
        Position trouverRoi(Couleur couleur) const;
        void gererCaseCliquee(const Position &position);
        std::shared_ptr<Piece> getPiece(const Position &position) const;
        static bool estPositionValide(const Position &position)
        {
            return position.x() >= 0 && position.x() < N_CASES 
                && position.y() >= 0 && position.y() < N_CASES;
        }
        void reset();
        void setPiecesSelectionnee(std::shared_ptr<Piece> piece);
        std::vector<std::vector<std::shared_ptr<Piece>>> &getCases() { return cases_; }
        const std::vector<std::vector<std::shared_ptr<Piece>>> &getCases() const { return cases_; }
        std::shared_ptr<Piece> getPiecesSelectionnee() const;
        static const int N_CASES = 8;
        void deplacerPiece(const Position &depart, const Position &fin);
        void placerUneVraiePartie();
        Modele::BlocInformation getBlocInformation() const;

    private:
        std::vector<std::vector<std::shared_ptr<Piece>>> cases_ = std::vector<std::vector<std::shared_ptr<Piece>>>(N_CASES, std::vector<std::shared_ptr<Piece>>(N_CASES, nullptr));
        std::unique_ptr<DeplacementManager> deplacementManager_;
    };

}